<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Report Issue</title>
<link rel="stylesheet" href="../css/erros.css">
</head>
<body>
<div class="background">
  <div class="report-box">
    <h2>"Algo de errado não está certo  \/(º>º)\/"</h2>
    <h2>Email e/ou Senha Inválido:</h2>
    <form>
      <a href="login.php" class="report-button">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        Tentar Novamente
      </a>
    </form>
  </div>
</div>
</body>
</html>