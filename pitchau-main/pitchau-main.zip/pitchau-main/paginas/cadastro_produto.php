<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/cadastro_produto.css">
  <title>Cadastro de Produto</title>
</head>

<body>
  <?php
  include_once "../consultas/flying_bubbles.php";
  $conn = connect();

  if (!isset($_SESSION["is_admin"]) || $_SESSION["is_admin"] == false) {
    header("Location: ../index.php");
  }

  // Função para gerar um nome único para a imagem
  function generateUniqueFileName($originalName) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $uniqueName = uniqid() . "." . $extension;
    return $uniqueName;
  }

  // Buscar categorias do banco de dados
  $sql = "SELECT id, nome FROM Categoria";
  $resultado = $conn->query($sql);
  $categorias = [];
  if ($resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
      $categorias[] = $row;
    }
  }
  
  ?>
  <form class="form" action="" method="post" enctype="multipart/form-data">
    <!-- ... (seu formulário) ... -->
    <form class="form" action="" method="post" enctype="multipart/form-data">
    <div class="container">
      <div class="header" id="imagePreviewContainer">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <!-- ... (seu código SVG) ... -->
                   
        </svg>
        <script>
          function previewImage(input) {
            var imagePreviewContainer = document.getElementById('imagePreviewContainer');
            var file = input.files[0];

            if (file) {
              var reader = new FileReader();
              reader.onload = function (e) {
                imagePreviewContainer.innerHTML = '<img src="' + e.target.result + '" alt="Imagem a ser carregada" style="width:300px">';
              };
              reader.readAsDataURL(file);
            } else {
              imagePreviewContainer.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <!-- ... (seu código SVG) ... --> </svg><p>Browse File to upload!</p>';
            }
          }
        </script>
        
      </div>
      <label for="foto" class="footer">
        <!-- ... (seu código SVG) ... -->
        <p>Selecione a foto do Produto</p>
        <!-- ... (seu código SVG) ... -->
      </label>
      <input id="foto" type="file" name="foto" onchange="previewImage(this)">
    </div>
    <div class="input-container">
      <input type="text" name="nome" placeholder="Nome">
      <span></span>
    </div>
    <div class="input-container">
      <input type="text" name="desc" placeholder="Descrição">
      <span></span>
    </div>
    <div class="input-container">
      <input type="number" name="valor" placeholder="Valor">
      <span></span>
    </div>
    <div class="input-container">
      <select name="categoria">
        <?php foreach ($categorias as $categoria): ?>
          <option value="<?php echo $categoria['id']; ?>">
            <?php echo $categoria['nome']; ?>
          </option>
        <?php endforeach; ?>
      </select>.
    </div>
    <button class="submit" name="submit">Cadastrar</button>
  </form>
  </form>
  <?php 
  if (isset($_POST['submit'])) {
    // Verifica se um arquivo foi enviado
    if (isset($_FILES['foto'])) {
      $arquivo = $_FILES['foto'];

      // Verifica se não houve erro no upload
      if ($arquivo['error'] === 0) {
        // Gera um nome único para a imagem
        $fotoNome = generateUniqueFileName($arquivo['name']);
        
        // Define o caminho para a pasta de destino
        $pastaDestino = "../img/img_produto/";
        $fotoCaminho = $pastaDestino . $fotoNome;

        // Move o arquivo para a pasta de destino
        move_uploaded_file($arquivo['tmp_name'], $fotoCaminho);

        // Restante do seu código para inserir os dados no banco de dados
        $nome = mysqli_real_escape_string($conn, $_POST["nome"]);
        $descricao = mysqli_real_escape_string($conn, $_POST["desc"]);
        $valor = mysqli_real_escape_string($conn, $_POST["valor"]);
        $categoria = mysqli_real_escape_string($conn, $_POST["categoria"]);

        $sql = "INSERT INTO Produto (nome, descricao, foto, valor, categoria_id) VALUES ('$nome', '$descricao', '$fotoNome', $valor, $categoria)";

        if ($conn->query($sql) === TRUE) {
          header("Location: ../index.php");
        } else {
          echo "Erro ao inserir no banco de dados: " . $conn->error;
        }
      } else {
        echo "Erro no upload de imagem: " . $arquivo['error'];
        // Lidar com erro de upload de imagem, se necessário
      }
    } else {
      echo "Nenhum arquivo enviado.";
    }
  }
  ?>

</body>

</html>

