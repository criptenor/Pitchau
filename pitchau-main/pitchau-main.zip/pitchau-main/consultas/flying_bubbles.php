<?php



function connect(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Pitchau";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Falha na conexão com o banco de dados: " . $conn->connect_error);
    }
    return $conn;
}

function carousel() {
    $conn = connect();
    
    // Consulta SQL para buscar todas as URLs de imagens da tabela "Slider"
    $sql = "SELECT url_img FROM Slider";
    $result = $conn->query($sql);
    $imagens=[];
    if ($result->num_rows > 0) {    
        while ($row = $result->fetch_assoc()) 
            array_push($imagens, $row);
    }
    // Fechando a conexão com o banco de dados
    $conn->close();
    
    //Retornando variavel para carrossel
    return $imagens;
}

function card_produtos(){
    $conn= connect();
    $sql = "SELECT * FROM Produto";
    $result = $conn->query($sql);
    $card_produto= [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc())
            array_push($card_produto, $row);
        //Fechando a conexão com o banco de dados
        $conn->close();
        //Retornanndo variavel para card de produto
        return $card_produto;
        
    }
}

function recuperar_produto_por_id($id_produto){
    $conn= connect();
    $sql = "SELECT * FROM Produto where id=$id_produto";
    $result = $conn->query($sql);
    $card_produto=null;
    if ($result->num_rows > 0) {
        if ($row = $result->fetch_assoc()) {
            $card_produto = $row;
        }
            
        //Fechando a conexão com o banco de dados
        $conn->close();
        //Retornanndo variavel para card de produto
        return $card_produto;
        
    }
}

function criar_carrinho( $min, $max, $cod_carrinho){
    $conn= connect();
    $min = 000000;
    $max = 999999;
    $cod_carrinho = rand($min, $max);
    $sql = "INSERT INTO Compra(id) VALUES($cod_carrinho)";

}

function add_produto_carrinho( $id_produto){
    $conn= connect();
    $sql = "SELECT * FROM Produto where id=$id_produto";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        if ($row = $result->fetch_assoc()) {
            $card_produto = $row;
        }
    }
}

function processar_login($email, $senha){
    $conn = connect();

    $sql = "SELECT id, nome, email, senha, isAdmin FROM Usuario WHERE email = '$email'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if ($senha == $row['senha']) {
            $_SESSION["user_id"] = $row["id"];
            $_SESSION["email"] = $email;
            $_SESSION["username"] = $row["nome"]; // Defina o nome de usuário aqui
            $_SESSION["is_admin"] = $row["isAdmin"];
            header("Location: ../index.php"); // Redirecionar para a página do painel após o login
            
        } 
        else{
            return 1;
        }
        
    }elseif($result->num_rows ==0){

        header("Location: ../paginas/login.php");
    } 
 
    
    else {
        return 2;
    }
}

function perfil(){

    // Verifica a conexão do usuario
if (isset($_SESSION["email"])) { 
    $email = $_SESSION["email"]; // Obtém o email do usuário da sessão

    // Use $emailUsuario para exibir informações do usuário ou realizar operações
    
} else {
    // Se o usuário não estiver logado, redirecione-o para a página de login
    header("Location: ../paginas/login.php");
    exit;
}
$conn = connect();
$sql = "SELECT nome, email FROM usuario WHERE email = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Erro na preparação da consulta: ' . $conn->error);
}
$stmt->bind_param("s",$email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $perfil = $result->fetch_assoc();
        $conn->close();
        return $perfil;
    } else {
        return array('nome' => 'Usuário não encontrado', 'email' => 'Email não encontrado');
}

}

function alterar_senha(){

}

function alterar_email($email, $senha){
    $conn= connect();
    $user_id= $_SESSION["user_id"]; //Variavel de sessão
    $sql= "SELECT email, senha FROM Usuario WHERE id= '$user_id'";
    $result=$conn->query($sql);
    if($result->num_rows > 0 ){
        $row= $result->fetch_assoc();
        if($senha == $row['senha']){
            $stmt=$conn->prepare("UPDATE Usuario SET email= ? WHERE id= ?");
            $stmt->bind_param("si",$email, $user_id );
            if ($stmt->execute()) {
                header("Location: ../php/logout.php");
            } else {
                echo "Erro ao alterar o e-mail: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Senha incorreta. A alteração de e-mail não foi realizada.";
        }      
    } else {
        echo "Usuário não encontrado.";
        $conn->close();
    }
}

function Apagar_conta(){
    $conn= connect($servername,$username,$password,$dbname);
    $user_id= $_SESSION["user_id"]; //Variavel de sessão
    $stmt = $conn->prepare("DELETE FROM Usuario WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $result= $stmt->execute();
    $stmt->close();
    $conn->close();
    return $result;
}

function getuser(){
    $conn= connect();
    $sql = "SELECT * FROM Usuario";
    $result = $conn->query($sql);
    $usuarios = [];
    // Verificar se há resultados
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $usuarios[] = $row;
        }
    }
    // Fechar a conexão
    $conn->close();

    return $usuarios;
}

function apagar_usuarios($id){
    $conn= connect();
    $sql = $conn->prepare("DELETE FROM usuario WHERE id = ?");
    
    if ($sql->execute()) {
        header("Location: ../paginas/visualizacaoUser.php");
    } else {
        echo "Erro ao excluir o usuário: " . $conn->error;
        return 1;
    }
    $sql->close();
}

function editName_usuarios( $id,$newName){
    $conn= connect();
    $sql = $conn->prepare("UPDATE usuario SET nome = ? WHERE id = ?");
    $sql->bind_param("si", $newName, $id);
    if ($sql->execute()) {
        header("Location: ../paginas/visualizacaoUser.php");
    } else {
        echo "Erro ao atualizar o nome do usuário: " . $conn->error;
        return 1;
        }
    $sql->close();
    }

function transform_admin($id){
    $conn= connect();
    $sql = $conn->prepare("UPDATE usuario set isAdmin = 1 WHERE id = ?");
    $sql->bind_param("i", $id);
    if ($sql->execute()) {
        header("Location: ../paginas/visualizacaoUser.php");
    } else {
        echo "Erro ao tornar admin:" . $conn->error;
        return 1;
    }
    $sql->close();

}

function insertIntoCarrinho($id_produto, $id_cliente, $quantidade) {
    // Substitua 'sua_tabela' pelo nome real da tabela no seu banco de dados
    $conn = connect();
    
    // Prepara a consulta SQL usando placeholders para prevenção de SQL injection
    $sql = $conn->prepare("INSERT INTO carrinho (id_produto, id_cliente, quantidade) VALUES (?, ?, ?)");
    
    // Associa os parâmetros aos placeholders e define os tipos de dados
    $sql->bind_param("iii", $id_produto, $id_cliente, $quantidade);
    
    // Executa a consulta SQL
    if ($sql->execute()) {
        header("Location: ../paginas/sucesso.php");
    } else {
        echo "Erro ao inserir no carrinho: " . $sql->error;
        return 1;
    }
    
    // Fecha a declaração SQL e a conexão
    $sql->close();
    $conn->close();
}
function getProdutosNoCarrinhoPorCliente($id_cliente) {
    $conn = connect();

    // Substitua 'sua_tabela_carrinho' pelo nome real da tabela carrinho no seu banco de dados
    $sql = $conn->prepare("SELECT id_produto, quantidade FROM carrinho WHERE id_cliente = ?");
    $sql->bind_param("i", $id_cliente);

    $sql->execute();
    $result = $sql->get_result();

    // Obter todos os resultados como um array associativo
    $produtos_no_carrinho = $result->fetch_all(MYSQLI_ASSOC);

    $sql->close();
    $conn->close();

    return $produtos_no_carrinho;
}

function getProdutoPorId($id_produto) {
    $conn = connect();

    // Substitua 'sua_tabela_produto' pelo nome real da tabela Produto no seu banco de dados
    $sql = $conn->prepare("SELECT * FROM Produto WHERE id = ?");
    $sql->bind_param("i", $id_produto);

    $sql->execute();
    $result = $sql->get_result();

    // Obter o resultado como um array associativo
    $produto = $result->fetch_assoc();

    $sql->close();
    $conn->close();

    return $produto;
}

// flying_bubbles.php

if (isset($_GET['method']) && $_GET['method'] == 'insertIntoCarrinho') {
    // Verifique e sanitize os parâmetros necessários, e em seguida, chame a função desejada
    if (isset($_GET['id_produto'])) {
        $id_produto = $_GET['id_produto'];
        insertIntoCarrinho($id_produto, $_SESSION["user_id"], 1);
        // Pode adicionar lógica de resposta aqui, se necessário
    }
    // Outros métodos podem ser adicionados da mesma forma
}


?>