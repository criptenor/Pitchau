<!DOCTYPE html>
<html lang="pt-br"> 
<head>
  
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/card_produtos.css">
    <link rel="stylesheet" href="css/slider.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Pitchau</title>
    <style>
      .card_ {
    
          --main-color: #000;
          --submain-color: #78858F;
          --bg-color: #fff;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
          position: relative;
          width: 100vw;
          display: flex;
          flex-direction: column;
          align-items: center;
          border-radius: 20px;
          background: var(--bg-color);
          border: none;
        }
        
        .card__img {
          height: 192px;
          width: 100%;
        }
        
        .card__img svg {
          height: 100%;
          border-radius: 20px 20px 0 0;
        }
        
        .card__avatar {
          position: absolute;
          width: 114px;
          height: 114px;
          background: var(--bg-color);
          border-radius: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          top: calc(50% - 57px);
        }
        
        .card__avatar svg {
          width: 100px;
          height: 100px;
        }
        
        .card__title {
          margin-top: 60px;
          font-weight: 500;
          font-size: 18px;
          color: var(--main-color);
        }
        
        .card__subtitle {
          margin-top: 10px;
          font-weight: 400;
          font-size: 15px;
          color: var(--submain-color);
        }
        
        .card__btn {
          margin-top: 15px;
          width: 200px;
          height: 31px;
          border: 2px solid var(--main-color);
          border-radius: 4px;
          font-weight: 700;
          font-size: 11px;
          color: var(--main-color);
          background: var(--bg-color);
          text-transform: uppercase;
          transition: all 0.3s;
        }
        
        .card__btn-solid {
          background: var(--main-color);
          color: var(--bg-color);
        }
        
        .card__btn:hover {
          background: var(--main-color);
          color: var(--bg-color);
        }
        
        .card__btn-solid:hover {
          background: var(--bg-color);
          color: var(--main-color);
        }

        .popup{
          background-color: #dadada;
          opacity: 0.8;
          position: fixed;
          /* justify-content: center; */
          bottom: 0;
          top: auto;
          width: 100vw;
          height: 100vh;
        }

        .card {
          
          
          position: fixed;
          width: 300px;
          height: 220px;
          background-color: rgb(255, 255, 255);
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 20px 30px;
          gap: 13px;
          position: relative;
          overflow: hidden;
          box-shadow: 2px 2px 20px rgba(0, 0, 0, 0.062);
        }
        
        #cookieSvg {
          width: 50px;
        }
        
        #cookieSvg g path {
          fill: rgb(97, 81, 81);
        }
        
        .cookieHeading {
          font-size: 1.2em;
          font-weight: 800;
          color: rgb(26, 26, 26);
        }
        
        .cookieDescription {
          text-align: center;
          font-size: 0.7em;
          font-weight: 600;
          color: rgb(99, 99, 99);
        }
        
        .cookieDescription a {
          --tw-text-opacity: 1;
          color: rgb(59 130 246);
        }
        
        .cookieDescription a:hover {
          -webkit-text-decoration-line: underline;
          text-decoration-line: underline;
        }
        
        .buttonContainer {
          display: flex;
          gap: 20px;
          flex-direction: row;
        }
        
        .acceptButton {
          width: 80px;
          height: 30px;
          background-color: #7b57ff;
          transition-duration: .2s;
          border: none;
          color: rgb(241, 241, 241);
          cursor: pointer;
          font-weight: 600;
          border-radius: 20px;
          box-shadow: 0 4px 6px -1px #977ef3, 0 2px 4px -1px #977ef3;
          transition: all .6s ease;
        }
        
        .declineButton {
          width: 80px;
          height: 30px;
          background-color: #dadada;
          transition-duration: .2s;
          color: rgb(46, 46, 46);
          border: none;
          cursor: not-allowed;
          font-weight: 600;
          border-radius: 20px;
          box-shadow: 0 4px 6px -1px #bebdbd, 0 2px 4px -1px #bebdbd;
          transition: all .6s ease;
        }
        
        .declineButton:hover {
          background-color: #ebebeb;
          box-shadow: 0 10px 15px -3px #bebdbd, 0 4px 6px -2px #bebdbd;
          transition-duration: .2s;
        }
        
        .acceptButton:hover {
          background-color: #9173ff;
          box-shadow: 0 10px 15px -3px #977ef3, 0 4px 6px -2px #977ef3;
          transition-duration: .2s;
        }
        .scrollable {
          overflow-y: auto; /* Adiciona uma barra de rolagem vertical quando necessário */
          max-height: 100vh; /* Define uma altura máxima para o carrinho para limitar o espaço ocupado */
      } 
      #carrinhoTela {
      position: fixed;
      top: 0;
      right: -100%; /* Inicialmente fora da tela */
      width: 33.33%; /* 1/3 da largura da tela */
      height: 100vh;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
      transition: right 0.3s ease; /* Adiciona uma transição suave */
      }

      #fecharCarrinho {
      position: absolute;
      top: 10px;
      right: 10px;   
      border: none;
          background: transparent;
      }
      .fixed-footer{
        position: absolute;
          bottom: 0;
          width:100%;
      }

      .fixed-footer .row{
        width:100%;
        margin-bottom:2%;
      }
      .bookmarkBtn {
        width: 250px;
        height: 40px;
        border-radius: 40px;
        border: 1px solid rgba(255, 255, 255, 0.349);
        background-color: rgb(12, 12, 12);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition-duration: 0.3s;
        overflow: hidden;
      }

      .IconContainer {
        width: 30px;
        height: 30px;
        background: linear-gradient(to bottom, rgb(255, 136, 255), rgb(172, 70, 255));
        border-radius: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        z-index: 2;
        transition-duration: 0.3s;
      }

      .icon {
        border-radius: 1px;
      }

      .text {
        height: 100%;
        margin:auto;  
        width: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        z-index: 1;
        transition-duration: 0.3s;
        font-size: 1.04em;
      }

      .bookmarkBtn:hover .IconContainer {
        width: 240px;
        transition-duration: 0.3s;
      }

      .bookmarkBtn:hover .text {
        transform: translate(10px);
        width: 0;
        font-size: 0;
        transition-duration: 0.3s;
      }

      .bookmarkBtn:active {
        transform: scale(0.95);
        transition-duration: 0.3s;
      }

    </style>
</head>
<body>
<?php
session_start();
 

 error_reporting(E_ALL);
 ini_set('display_errors', '1');
 
 
 // Resto do código...
 
 
  include_once "consultas/flying_bubbles.php";
  if (!isset($_SESSION["user_id"]) && !isset($_SESSION["is_admin"])) { //Verifica se == Usuário Logado ou == Administrador
    echo "<input type='hidden' id='menulevel' value='1'/>";
  }
  if (isset($_SESSION["user_id"])) { //Verifica se == Usuário Logado
    if (isset($_SESSION["is_admin"]) && $_SESSION["is_admin"]== 1 ) { //Verifica se == Administrador
      echo "<input type='hidden' id='menulevel' value='3'/>";
    }
  else echo "<input type='hidden' id='menulevel' value='2'/>";
  }
  
  
  

?>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><img src="img/PITCHAU.png" alt=""></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Menu
          </a>
          <ul class="dropdown-menu">
          <div id="menu"></div>
          <script>
            menulevel = document.getElementById("menulevel").value;
            var menu = '';
            if(menulevel == '1'){
              menu = '<li><a class="dropdown-item" href="paginas/login.php">Fazer Login</a></li><li><a class="dropdown-item" href="paginas/cadastro.php">Se Cadastrar</a></li>';
            }
            else if(menulevel == '2'){
              menu = '<li><a class="dropdown-item" href="paginas/perfil.php">Perfil</a></li><li><a class="dropdown-item" href="paginas/carrinho.php">Carrinho</a></li><li><a class="dropdown-item" href="paginas/produtos_comprados.php">Prod Comprado</a></li><li><a class="dropdown-item" href="php/logout.php">Logout</a></li>';
            }
            else if(menulevel == '3'){
              menu = '<li><a class="dropdown-item" href="paginas/perfil.php">Perfil</a></li><li><a class="dropdown-item" href="paginas/categoria.php">Criar Categoria</a></li><li><a class="dropdown-item" href="paginas/cadastro_produto.php">Criar Produto</a></li><li><a class="dropdown-item" href="paginas/produtos_vendidos.php">Relação de vendas</a></li><li><a class="dropdown-item" href="paginas/visualizacaoUser.php">Visualização Usuários</a></li><li><a class="dropdown-item" href="php/logout.php">Logout</a></li>';
            }
            
            document.getElementById("menu").innerHTML = menu;
          </script>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<?php
var_dump($_SESSION);
 print_r('informações: ' . $_SESSION);
echo '<p> informações:'. $_SESSION['user_id'] . $_SESSION['email'] . $_SESSION['senha'] . '</p>';

$imagens = carousel();

if ($imagens != null) {
    echo '<div id="carouselExample" class="carousel slide">';
    echo '<div class="carousel-inner">';
    $first = true; // Variável para controlar o primeiro item do carrossel
    foreach ($imagens as $imagem) {
        $url_img = $imagem["url_img"];
        echo '<div class="carousel-item ' . ($first ? 'active' : '') . '">';
        echo '<img src="' . $url_img . '" class="d-block w-100" alt="...">';
        echo '</div>';
        $first = false; // Desativar a flag após o primeiro item
    }

    echo '</div>';
    echo '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">';
    echo '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
    echo '<span class="visually-hidden">Previous</span>';
    echo '</button>';
    echo '<button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">';
    echo '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
    echo '<span class="visually-hidden">Next</span>';
    echo '</button>';
    echo '</div>';
} else {
    echo "Nenhuma imagem encontrada na tabela Slider.";
}


?>
 


 <script>
  document.addEventListener('DOMContentLoaded', function () {
  const carrinhoTela = document.getElementById('carrinhoTela');

  window.toggleCarrinho = function() {
  console.log("Toggle carrinho chamado");
  
  // Verifique se o carrinho está aberto ou fechado
  var carrinhoAberto = carrinhoTela.style.right === '0%';

  // Alterne entre abrir e fechar com base no estado atual
  carrinhoTela.style.right = carrinhoAberto ? '-100%' : '0%';
};


  // Opcional: Fechar carrinho se clicar fora dele
  window.addEventListener('click', function (event) {
    if (event.target === carrinhoTela) {
      toggleCarrinho();
    }
  });
});


  </script>
<div class="card_list">   
  <?php //Cards
  echo $_SESSION['user_id'];
  $card_produto= card_produtos();
    if($card_produto != null){
      foreach($card_produto as $card_produto) {
        echo '<div class="card" style="height:350px">';
        echo '<div class="card-img">';
        $imagem=$card_produto['foto'];
        $imagem= 'img/img_produtos/' . $imagem;
        echo '<img src="' . $imagem . '" class="d-block w-100" alt="...">';
        echo '</div>';
        echo '<div class="card-info">';
        echo '<p class="text-title">' . $card_produto["nome"] . '</p>';
        echo '<p class="text-body">' . $card_produto["descricao"] . '</p>';
        echo '<p class="text-body">' . $card_produto["id"] . '</p>';
        echo '</div>';

        echo '<div class="card-footer">';
        echo '<span class="text-title">$' . number_format($card_produto["valor"], 2) . '</span>';
        
        // Adicionando um identificador único ao botão (id_produto) e removendo a chamada direta da função PHP
        echo '<button class="card-button" id="addcart_' . $card_produto['id'] . '_carrinho" onclick="adicionarAoCarrinho(' . $card_produto['id'] . ');">';
        
        echo '<svg class="svg-icon" viewBox="0 0 20 20">';
        echo '<path d="M17.72,5.011H8.026c-0.271,0-0.49,0.219-0.49,0.489c0,0.271,0.219,0.489,0.49,0.489h8.962l-1.979,4.773H6.763L4.935,5.343C4.926,5.316,4.897,5.309,4.884,5.286c-0.011-0.024,0-0.051-0.017-0.074C4.833,5.166,4.025,4.081,2.33,3.908C2.068,3.883,1.822,4.075,1.795,4.344C1.767,4.612,1.962,4.853,2.231,4.88c1.143,0.118,1.703,0.738,1.808,0.866l1.91,5.661c0.066,0.199,0.252,0.333,0.463,0.333h8.924c0.116,0,0.22-0.053,0.308-0.128c0.027-0.023,0.042-0.048,0.063-0.076c0.026-0.034,0.063-0.058,0.08-0.099l2.384-5.75c0.062-0.151,0.046-0.323-0.045-0.458C18.036,5.092,17.883,5.011,17.72,5.011z"></path>';
        echo '<path d="M8.251,12.386c-1.023,0-1.856,0.834-1.856,1.856s0.833,1.853,1.856,1.853c1.021,0,1.853-0.83,1.853-1.853S9.273,12.386,8.251,12.386z M8.251,15.116c-0.484,0-0.877-0.393-0.877-0.874c0-0.484,0.394-0.878,0.877-0.878c0.482,0,0.875,0.394,0.875,0.878C9.126,14.724,8.733,15.116,8.251,15.116z"></path>';
        echo '<path d="M13.972,12.386c-1.022,0-1.855,0.834-1.855,1.856s0.833,1.853,1.855,1.853s1.854-0.83,1.854-1.853S14.994,12.386,13.972,12.386z M13.972,15.116c-0.484,0-0.878-0.393-0.878-0.874c0-0.484,0.394-0.878,0.878-0.878c0.482,0,0.875,0.394,0.875,0.878C14.847,14.724,14.454,15.116,13.972,15.116z"></path>';
        echo '</svg>';
        echo '</button>'; #fecha botão
        echo '</div>'; #fecha footer
        echo '</div>'; #fechacard
      }
    } else {
      echo "Nenhum produto encontrado na tabela Produto.";
    }
  ?>
</div>

<!-- Adicionando um script JavaScript para lidar com a chamada assíncrona -->
<script>
  function adicionarAoCarrinho(id_produto) {
    // Utilize AJAX para fazer a chamada assíncrona da função PHP
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        // Você pode adicionar aqui alguma lógica para lidar com a resposta, se necessário
         // Se quiser fechar o carrinho após adicionar ao carrinho
      }
    };
    
    // Substitua 'caminho_do_arquivo' pelo caminho real do arquivo PHP que contém a função insertIntoCarrinho
    xmlhttp.open("GET", "consultas/flying_bubbles.php?method=insertIntoCarrinho&id_produto=" + id_produto, true);
    toggleCarrinho();
    xmlhttp.send();
  }
</script>
                                   
</div>
<div id="carrinhoTela" class="scrollable">

  <button class="button"  id="fecharCarrinho" class="fecharCarrinho" onclick="toggleCarrinho();">
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 14.41L14.41 17 12 14.59 9.59 17 7 14.41 9.59 12 7 9.59 9.59 7 12 9.59 14.41 7 17 9.59 14.41 12 17 14.41z"/>
</svg>

  </button>

  <div class="card_list">
    <?php
    $produtos_no_carrinho = getProdutosNoCarrinhoPorCliente($_SESSION['user_id']);
    echo 'primeiro produto' . $produtos_no_carrinho[0];
    echo 'user id' . $_SESSION['user_id'];

    // Cards
    if ($produtos_no_carrinho != null) {
        foreach ($produtos_no_carrinho as $produto_carrinho) {
            $id_produto = $produto_carrinho['id_produto'];
            $quantidade = $produto_carrinho['quantidade'];

            // Obter informações do produto por id
            $produto = getProdutoPorId($id_produto);

            if ($produto) {
                // Seu código para exibir cada card aqui
                echo '<div class="card" style="height:350px">';
                echo '<div class="card-img">';
                $imagem = 'img/img_produtos/' . $produto['foto'];
                echo '<img src="' . $imagem . '" class="d-block w-100" alt="...">';
                echo '</div>';
                echo '<div class="card-info">';
                echo '<p class="text-title">' . $produto["nome"] . '</p>';
                echo '<p class="text-body">' . $produto["descricao"] . '</p>';
                echo '</div>';

                echo '<div class="card-footer">';
                echo '<span class="text-title">$' . number_format($produto["valor"], 2) . '</span>';
                echo '<span class="text-body">Quantidade: ' . $quantidade . '</span>';
                // Adicione qualquer outro detalhe que desejar mostrar no card
                echo '</div>';

                echo '</div>';
            }
        }
    } else {
        echo "Nenhum produto encontrado no carrinho.";
    }
    ?>
  </div>
  <div class="fixed-footer">
  <div class="container text-center">
  <div class="row">
    <div class="col"></div>
  
    <div class="col">
    <button class="bookmarkBtn">
  <span class="IconContainer">
    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="32" viewBox="0 0 50 32">
  <!-- Corpo do cartão -->
  <rect width="50" height="32" rx="4" fill="#000" />

  <!-- Chip do cartão -->
  <rect x="6" y="6" width="8" height="8" rx="2" fill="white" />

  <!-- Tarja magnética -->
  <rect x="4" y="20" width="42" height="6" rx="2" fill="white" />

  <!-- Números do cartão (fictícios) -->
  <text x="10" y="28" font-family="Arial, sans-serif" font-size="8" fill="#fff">1234</text>
  <text x="20" y="28" font-family="Arial, sans-serif" font-size="8" fill="#fff">5678</text>
  <text x="30" y="28" font-family="Arial, sans-serif" font-size="8" fill="#fff">9012</text>
  <text x="40" y="28" font-family="Arial, sans-serif" font-size="8" fill="#fff">3456</text>
</svg>

  </span>
  <p class="text">Save</p>
</button>

  
      
    </div>
    <div class="col"></div>

  </div>
</div>
 
  </div>

  <!-- Conteúdo do carrinho aqui -->
  
</div>

<script>
  // Adicione um script JavaScript para lidar com os eventos do mouse
  var carrinhoTela = document.getElementById('carrinhoTela');

  carrinhoTela.addEventListener('mouseenter', function() {
    carrinhoTela.classList.add('scrollable');
  });

  carrinhoTela.addEventListener('mouseleave', function() {
    carrinhoTela.classList.remove('scrollable');
  });
</script>
  
</body>
</html>
