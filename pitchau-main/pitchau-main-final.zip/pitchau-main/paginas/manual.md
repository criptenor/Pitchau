# Cliente
* Passo 1: Realize o cadastro, colocando as seguintes informações (nome, sobrenome, email, senha e confirmar senha)
* Passo 2: Feito isso, será redirecionado para a página de login , onde ira preencher com suas informações
* Passo 3: Ao efetuar o login, o usuário será redirecionado para a página Principal.
* Passo 4: Na página principal o usuário poderá visualizar os produtos disponíveis ‚adquirir e ou cadastrar um produto para venda
# Comprando o produto
* Passo 1: Na pagina principal escolha o produto ou pesquise na opção buscar
  Passo 2: Após isso adcione o produto no carrinho 
  passo 3: confirme suas informções 
# Vendendo o produto
* Passo 1 : Na página principal, clique em menu
* Passo 2 clique em criar produto
* Passo 3 cadastre seu produto colocando as seguintes informações (foto, nome, descrição, valor )
# Administrador
* Caso o usuário seja uma Administrador, ao realizar o login será redirecionado para página princinpal com funções exclusivas. 
* O administrador poderá adicionar novos produtos ao site inserindo seu nome, preço, descrição e uma imagem "clicando em criar produto"
* O Administrador poderá também remover produtos presentes no site. 
* O Administrador será capaz de cadastrar outros administradores clicando em "tornar adm". 
* O Administrador poderá ver a relação dos produtos presentes no site.