import subprocess

# Substitua os valores abaixo pelos seus próprios dados
usuario = ""
senha = ""
banco_de_dados = "Pitchau"
caminho_do_backup = "backup_pitchau.sql"

# Comando mysqldump para criar o backup
comando = f"mysqldump -u {usuario} -p{senha} {banco_de_dados} > {caminho_do_backup}"

# Executando o comando usando subprocess
try:
    subprocess.run(comando, shell=True, check=True)
    print("Backup realizado com sucesso!")
except subprocess.CalledProcessError as e:
    print(f"Ocorreu um erro ao fazer o backup: {e}")
