-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 09/02/2024 às 04:22
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `Pitchau`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrinho`
--

CREATE TABLE `carrinho` (
  `id` int(11) NOT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `carrinho`
--

INSERT INTO `carrinho` (`id`, `id_produto`, `id_cliente`, `quantidade`) VALUES
(379, 24, NULL, 1),
(380, 24, NULL, 1),
(381, 24, NULL, 1),
(405, 25, 1, 1),
(406, 26, 1, 1),
(407, 25, 1, 1),
(408, 25, 1, 1),
(409, 25, 1, 1),
(410, 25, 1, 1),
(411, 25, 1, 1),
(412, 25, 1, 1),
(413, 25, 1, 1),
(414, 30, 1, 1),
(415, 33, 1, 1),
(416, 33, 1, 1),
(417, 33, 1, 1),
(418, 33, 1, 1),
(419, 33, 1, 1),
(420, 33, 1, 1),
(421, 33, 1, 1),
(422, 33, 1, 1),
(423, 33, 1, 1),
(424, 33, 1, 1),
(425, 33, 1, 1),
(426, 33, 1, 1),
(427, 33, 1, 1),
(428, 33, 1, 1),
(429, 33, 1, 1),
(430, 33, 1, 1),
(431, 33, 1, 1),
(432, 33, 1, 1),
(433, 33, 1, 1),
(434, 33, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Categoria`
--

CREATE TABLE `Categoria` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `Categoria`
--

INSERT INTO `Categoria` (`id`, `nome`) VALUES
(1, 'Sopro'),
(2, 'Cordas'),
(3, 'Percussão'),
(4, 'Teclas'),
(5, 'Sopro'),
(6, 'Sopro'),
(7, 'Sopro'),
(8, 'Cordas'),
(9, 'Cordas'),
(10, 'Percussão'),
(11, 'Cordas'),
(12, 'Percussão'),
(13, 'Teclas'),
(14, 'Percussão'),
(15, 'Teclas'),
(16, 'Teclas'),
(17, 'ADEILTON DOS SANTOS SILVA FILHO'),
(18, 'sfsf'),
(19, 'coisas lindas');

-- --------------------------------------------------------

--
-- Estrutura para tabela `Compra`
--

CREATE TABLE `Compra` (
  `id_compra` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `dataehora` datetime DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `Compra`
--

INSERT INTO `Compra` (`id_compra`, `usuario_id`, `dataehora`, `valor`) VALUES
(1, 1, '2024-01-24 03:41:33', 134600.00),
(2, 1, '2024-01-24 03:42:43', 7000.00),
(3, 1, '2024-01-24 03:54:37', 27800.00),
(4, 1, '2024-01-24 04:04:46', 3000.00),
(5, 1, '2024-01-24 18:02:42', 57000.00),
(6, 1, '2024-01-24 19:36:52', 35200.00),
(7, 1, '2024-01-24 21:58:47', 20600.00),
(8, 1, '2024-01-25 00:01:27', 1800.00),
(9, 1, '2024-01-25 00:43:18', 1800.00),
(10, 1, '2024-01-25 03:05:08', 500.00),
(11, 1, '2024-01-25 03:19:35', 500.00),
(12, 1, '2024-02-09 00:58:56', 8300.00),
(13, 496, '2024-02-09 01:46:01', 6156.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Produto`
--

CREATE TABLE `Produto` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `quantidade_estoque` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `Produto`
--

INSERT INTO `Produto` (`id`, `nome`, `descricao`, `foto`, `valor`, `categoria_id`, `quantidade_estoque`) VALUES
(24, 'Flauta Doce', NULL, 'Flauta_doce.png', 100.00, 1, NULL),
(25, 'Guitarra Acácia', NULL, 'Guitarra_acacia.png', 500.00, 2, NULL),
(26, 'Guitarra Boxe', NULL, 'Guitarra_boxe.png', 550.00, 2, NULL),
(27, 'Guitarra', NULL, 'Guitarra.png', 450.00, 2, NULL),
(28, 'Trombone', NULL, 'Trombone.png', 300.00, 1, NULL),
(29, 'Trompete', NULL, 'Trompete.png', 250.00, 1, NULL),
(30, 'Viola Elétrica', NULL, 'Viola_eletrica.png', 700.00, 2, NULL),
(31, 'Violão Clássico', NULL, 'Violao_classico.png', 200.00, 2, NULL),
(32, 'Violão Zion', NULL, 'Violao_zion.png', 300.00, 2, NULL),
(33, 'Violino', NULL, 'Violino.png', 400.00, 2, NULL),
(34, 'ADEILTON DOS SANTOS SILVA FILHO', '555', '65c56eae93903.jpeg', 5456.00, 19, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Slider`
--

CREATE TABLE `Slider` (
  `id` int(11) NOT NULL,
  `url_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `Slider`
--

INSERT INTO `Slider` (`id`, `url_img`) VALUES
(1, 'img/img_slider/slider.png'),
(2, 'img/img_slider/slider_2.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `Usuario`
--

CREATE TABLE `Usuario` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `foto` varchar(255) DEFAULT 'foto_padrao.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `Usuario`
--

INSERT INTO `Usuario` (`id`, `email`, `senha`, `nome`, `isAdmin`, `foto`) VALUES
(496, 'ola@gmail.com', '123456', 'Adeilton Dos Sants Silva Filho', 1, 'foto_padrao.png'),
(497, 'toco@gmail.com', '123456', 'Adeilton dos Santos Silva Filho', 0, 'foto_padrao.png');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `carrinho`
--
ALTER TABLE `carrinho`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `Categoria`
--
ALTER TABLE `Categoria`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `Compra`
--
ALTER TABLE `Compra`
  ADD PRIMARY KEY (`id_compra`);

--
-- Índices de tabela `Produto`
--
ALTER TABLE `Produto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Índices de tabela `Slider`
--
ALTER TABLE `Slider`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `carrinho`
--
ALTER TABLE `carrinho`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=438;

--
-- AUTO_INCREMENT de tabela `Categoria`
--
ALTER TABLE `Categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `Compra`
--
ALTER TABLE `Compra`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `Produto`
--
ALTER TABLE `Produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de tabela `Slider`
--
ALTER TABLE `Slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `Usuario`
--
ALTER TABLE `Usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=498;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `Produto`
--
ALTER TABLE `Produto`
  ADD CONSTRAINT `Produto_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;