# Manual do Usuário

Na Pitchau o visitante, já cadastrado como: usuário ou administrador podera realizar a compra de produtos musicais virtualmente. O visitante poderá se cadastrar como usuário atravéz da página de registro, e então realizar seu login, atravéz da página de login. O adminstrador poderá ser cadastrado por meio de outro adminstrador. Além de um adminstrador primário, que é já definido na base do site.

**Lista das Funcionalidades:**

 - [Funcionalidade Comprar Produto](#Funcionalidade-Comprar-Produto)
 - [Funcionalidade Editar Produto](#Funcionalidade-Editar-Produto)
 - [Funcionalidade Z](#Funcionalidade-Z)

## Funcionalidade Comprar Produto

Para a realização de compra de um produto, o usuário ou adminstador, cadastrado, deverá escolher o produto que deseja comprar, abrir-lo, e então tocar a opção de comprar. Realizando assim sua compra. 

## Funcionalidade Editar Produto

Para a Edição de um produto, um administrador deverá escolher o produto que deseja editar, abri-lo, tocar a opção de alterar, fazer as alterações desejadas, e então salvar.

## Funcionalidade Z

Sed consequat, diam in imperdiet fringilla, magna metus vehicula ipsum, eu tincidunt massa dolor eget lorem. Integer pellentesque in massa in eleifend. Phasellus a interdum enim. Nullam malesuada nulla eu mi vestibulum imperdiet. Maecenas diam dolor, commodo eget commodo at, congue in libero. Morbi non erat enim. Nunc faucibus lacus urna. Aliquam erat volutpat. Aliquam ex nunc, dictum vel libero sit amet, varius pulvinar risus. Aenean tempus magna at nulla elementum, vel feugiat turpis sodales. Vestibulum viverra congue nibh sed tempor. Morbi faucibus rhoncus dictum. Vestibulum rutrum, nisi id porttitor posuere, purus leo accumsan turpis, sit amet rutrum nulla turpis sit amet ex. Sed ultricies pharetra libero, sed tempor tellus hendrerit eget. Maecenas nibh sem, accumsan ullamcorper felis sed, pharetra semper dolor. Pellentesque ornare lorem eu condimentum tincidunt.

Nam lacinia gravida velit et ultricies. Quisque blandit a ligula at tincidunt. Vestibulum id odio a lectus maximus tempor non in augue. Duis vulputate dui vitae lacus ornare, et eleifend erat cursus. Mauris viverra, massa vel eleifend tempus, nunc justo tempus quam, ac sollicitudin lorem arcu vitae magna. Aliquam eleifend diam neque, at sagittis eros scelerisque vitae. Sed convallis iaculis tempor. Pellentesque in varius velit. Cras ut risus at ligula tristique tincidunt ac a risus. Morbi egestas tincidunt nunc, molestie aliquam nisl imperdiet egestas. Morbi hendrerit augue ac accumsan posuere. Sed a sodales elit. Nullam pharetra rhoncus arcu, eget pharetra massa egestas ut. Sed accumsan auctor dictum. Duis leo enim, pulvinar ut enim a, tempor aliquam dui. Nunc aliquet quam justo, sed aliquet justo tincidunt sed.
