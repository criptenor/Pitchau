<?php
    include_once "../consultas/flying_bubbles.php";
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    
    $conn=connect();

    // Verifique se o formulário foi enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // Coletar dados do formulário
        $password_ = $_POST["senha"];
        $confirm_password = $_POST["confirm_senha"];
        if ($password_ == $confirm_password){
            // Validar os dados (adicionar validações adicionais conforme necessário)

        // Inserir dados na tabela Usuario
        $stmt = $conn->prepare("UPDATE Usuario SET senha = ? WHERE id = ?");
        $stmt->bind_param("si", $password_, $_SESSION["user_id"]); // Alterado a ordem dos parâmetros
        
        if ($stmt->execute()) {
            header("Location: ../paginas/perfil.php");
            exit;
        } else {
            header("Location: ../paginas/perfil.php");
        }
        

        // Fechar a conexão com o banco de dados
        $conn->close();
        }
        else{
            header("Location: ../index.php");
        }

        
    }
?>
